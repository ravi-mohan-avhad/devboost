# Contributing to JDL-Studio

To start contributing you will need to fork the repo on github and clone it first.

## Building

Running `npm install` and run `gulp` to start local dev server

The development is done on `index-dev.html`.
Run `gulp build` to build an `index.html` with optimized JS and CSS files.
Run `gulp inject` after any modification to `bower.json` or after changing file names in `lib.js`
