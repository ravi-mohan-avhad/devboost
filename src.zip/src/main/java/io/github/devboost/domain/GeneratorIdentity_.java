package io.github.devboost.domain;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(GeneratorIdentity.class)
public abstract class GeneratorIdentity_ {

	public static volatile SingularAttribute<GeneratorIdentity, User> owner;
	public static volatile SingularAttribute<GeneratorIdentity, String> host;
	public static volatile SingularAttribute<GeneratorIdentity, String> guid;
	public static volatile SingularAttribute<GeneratorIdentity, Long> id;

}

