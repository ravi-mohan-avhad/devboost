package io.github.devboost.domain.interfaces;

public interface DatabaseColumn {

    String getDatabaseValue();
}
