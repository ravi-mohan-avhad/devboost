package io.github.devboost.domain;

import java.time.Instant;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(YoRC.class)
public abstract class YoRC_ {

	public static volatile SingularAttribute<YoRC, String> applicationType;
	public static volatile SingularAttribute<YoRC, String> memory;
	public static volatile SingularAttribute<YoRC, Integer> week;
	public static volatile SingularAttribute<YoRC, String> jhipsterVersion;
	public static volatile SingularAttribute<YoRC, Integer> year;
	public static volatile SingularAttribute<YoRC, Boolean> serviceDiscoveryType;
	public static volatile SingularAttribute<YoRC, String> devDatabaseType;
	public static volatile SingularAttribute<YoRC, String> gitProvider;
	public static volatile SingularAttribute<YoRC, String> nativeLanguage;
	public static volatile SingularAttribute<YoRC, String> serverPort;
	public static volatile SingularAttribute<YoRC, String> userLanguage;
	public static volatile SingularAttribute<YoRC, Boolean> messageBroker;
	public static volatile SingularAttribute<YoRC, Boolean> hasProtractor;
	public static volatile SingularAttribute<YoRC, String> cores;
	public static volatile SingularAttribute<YoRC, String> cacheProvider;
	public static volatile SingularAttribute<YoRC, Integer> hour;
	public static volatile SingularAttribute<YoRC, Boolean> hasCucumber;
	public static volatile SingularAttribute<YoRC, Boolean> websocket;
	public static volatile SingularAttribute<YoRC, String> buildTool;
	public static volatile SingularAttribute<YoRC, Long> id;
	public static volatile SingularAttribute<YoRC, String> prodDatabaseType;
	public static volatile SingularAttribute<YoRC, Integer> day;
	public static volatile SingularAttribute<YoRC, GeneratorIdentity> owner;
	public static volatile SingularAttribute<YoRC, Boolean> enableTranslation;
	public static volatile SingularAttribute<YoRC, String> os;
	public static volatile SingularAttribute<YoRC, Boolean> searchEngine;
	public static volatile SingularAttribute<YoRC, String> jhiPrefix;
	public static volatile SingularAttribute<YoRC, String> cpu;
	public static volatile SingularAttribute<YoRC, String> nodeVersion;
	public static volatile SingularAttribute<YoRC, Instant> creationDate;
	public static volatile SingularAttribute<YoRC, String> clientPackageManager;
	public static volatile SingularAttribute<YoRC, String> databaseType;
	public static volatile SetAttribute<YoRC, String> selectedLanguages;
	public static volatile SingularAttribute<YoRC, Integer> month;
	public static volatile SingularAttribute<YoRC, Boolean> enableSwaggerCodegen;
	public static volatile SingularAttribute<YoRC, Boolean> hasGatling;
	public static volatile SingularAttribute<YoRC, String> clientFramework;
	public static volatile SingularAttribute<YoRC, Boolean> enableHibernateCache;
	public static volatile SingularAttribute<YoRC, Boolean> useSass;
	public static volatile SingularAttribute<YoRC, String> arch;
	public static volatile SingularAttribute<YoRC, String> authenticationType;

}

